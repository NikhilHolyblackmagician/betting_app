import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import json
from database.db import create_connection


class TeamWindow:
    def __init__(self, master):
        self.master = master
        self.window = tk.Toplevel(master)
        self.window.title("Team Manager")
        self.window.geometry("1200x680")

        self.selected_team_id = None
        self._create_widgets()
        self._load_teams()

    def _create_widgets(self):
        # Search Frame
        search_frame = ttk.Frame(self.window)
        search_frame.pack(fill=tk.X, padx=10, pady=5)

        self.search_var = tk.StringVar()
        ttk.Entry(search_frame, textvariable=self.search_var, width=40).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(search_frame, text="Search", command=self._search_teams).pack(side=tk.LEFT)
        ttk.Button(search_frame, text="Clear", command=self._clear_search).pack(side=tk.LEFT, padx=5)

        # Main Content
        content = ttk.Frame(self.window)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self._create_team_tree(content)
        self._create_team_form(content)

    def _create_team_tree(self, parent):
        frame = ttk.Frame(parent)
        frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        cols = ("ID", "Team Name", "Event", "Event Date", "Created At")
        self.team_tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse")

        for col in cols:
            self.team_tree.heading(col, text=col)
            self.team_tree.column(col, width=120 if col != "Event" else 200, anchor="center")

        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.team_tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=self.team_tree.xview)
        self.team_tree.configure(yscroll=vsb.set, xscroll=hsb.set)

        self.team_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.team_tree.bind("<<TreeviewSelect>>", self._on_team_select)

    def _create_team_form(self, parent):
        form = ttk.Frame(parent)
        form.pack(side=tk.LEFT, fill=tk.Y, padx=(10, 0))

        # Form Fields
        fields = [
            ("Team Name:", "team_name"),
            ("Event Name:", "event_name"),
            ("Event Date:", "event_date"),
            ("Captain:", "captain"),
            ("Home Ground:", "home_ground")
        ]

        self.entries = {}
        for row, (label, field) in enumerate(fields):
            ttk.Label(form, text=label).grid(row=row, column=0, sticky="e", pady=2)
            entry = ttk.Entry(form, width=30)
            entry.grid(row=row, column=1, pady=2, sticky="w")
            self.entries[field] = entry

        # Buttons
        btn_frame = ttk.Frame(form)
        btn_frame.grid(row=len(fields) + 1, column=0, columnspan=2, pady=10)

        ttk.Button(btn_frame, text="Save", command=self._save_team).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Clear", command=self._clear_form).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Delete", command=self._delete_team).pack(side=tk.LEFT, padx=5)

    def _load_teams(self, search_term=None):
        conn = create_connection()
        cursor = conn.cursor()

        query = """SELECT team_id, team_name, event_name, event_date, created_at 
                   FROM teams"""
        params = ()

        if search_term:
            query += " WHERE team_name LIKE ? OR event_name LIKE ?"
            params = (f"%{search_term}%", f"%{search_term}%")

        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()

        self.team_tree.delete(*self.team_tree.get_children())
        for row in rows:
            self.team_tree.insert("", tk.END, values=row)

    def _save_team(self):
        data = {field: entry.get().strip() for field, entry in self.entries.items()}

        if not data["team_name"]:
            messagebox.showwarning("Validation", "Team Name is required!")
            return

        conn = create_connection()
        cursor = conn.cursor()

        try:
            if self.selected_team_id:
                cursor.execute("""UPDATE teams SET 
                                    team_name=?,
                                    event_name=?,
                                    event_date=?,
                                    captain=?,
                                    home_ground=?
                                WHERE team_id=?""",
                               (data["team_name"], data["event_name"], data["event_date"],
                                data["captain"], data["home_ground"], self.selected_team_id))
            else:
                cursor.execute("""INSERT INTO teams 
                                (team_name, event_name, event_date, captain, home_ground)
                                VALUES (?, ?, ?, ?, ?)""",
                               (data["team_name"], data["event_name"], data["event_date"],
                                data["captain"], data["home_ground"]))

            conn.commit()
            self._load_teams()
            self._clear_form()
            messagebox.showinfo("Success", "Team saved successfully!")

        except Exception as e:
            messagebox.showerror("Database Error", f"Error saving team: {str(e)}")
        finally:
            conn.close()

    def _on_team_select(self, event):
        selection = self.team_tree.selection()
        if not selection:
            return

        item = self.team_tree.item(selection[0])
        values = item["values"]
        self.selected_team_id = values[0]

        # Populate form fields
        fields = ["team_name", "event_name", "event_date", "captain", "home_ground"]
        for i, field in enumerate(fields, start=1):
            self.entries[field].delete(0, tk.END)
            self.entries[field].insert(0, values[i] if i < len(values) else "")

    def _clear_form(self):
        self.selected_team_id = None
        for entry in self.entries.values():
            entry.delete(0, tk.END)
        self.team_tree.selection_remove(self.team_tree.selection())

    def _delete_team(self):
        if not self.selected_team_id:
            return

        if messagebox.askyesno("Confirm Delete", "Delete this team?"):
            conn = create_connection()
            cursor = conn.cursor()

            try:
                cursor.execute("DELETE FROM teams WHERE team_id=?", (self.selected_team_id,))
                conn.commit()
                self._load_teams()
                self._clear_form()
            except Exception as e:
                messagebox.showerror("Error", f"Could not delete team: {str(e)}")
            finally:
                conn.close()

    def _search_teams(self):
        self._load_teams(self.search_var.get().strip())

    def _clear_search(self):
        self.search_var.set("")
        self._load_teams()