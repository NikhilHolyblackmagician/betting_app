import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime
from database.db import create_connection


# ───────────────────────────────────────────────────────────────
#  Make sure the sessions table (or equivalent) exists:
#
#  CREATE TABLE IF NOT EXISTS sessions (
#      session_id     INTEGER PRIMARY KEY,
#      match_id       INTEGER NOT NULL,
#      bettor         TEXT    NOT NULL,
#      rate_pct       REAL    NOT NULL,
#      stake_amount   REAL    NOT NULL,
#      target_runs    INTEGER NOT NULL,
#      status         TEXT    NOT NULL DEFAULT 'Pending',  -- Pending | Declared
#      declared_runs  INTEGER,
#      created_at     TEXT    NOT NULL,
#      declared_at    TEXT,
#      FOREIGN KEY (match_id) REFERENCES matches(match_id)
#  );
# ───────────────────────────────────────────────────────────────


class DeclareReportWindow:
    """List every saved session and let the user declare (or undeclare) its result."""

    COLS = (
        "ID", "Match", "Bettor", "Stake",
        "Target", "Status", "Declared Runs", "Created At"
    )

    def __init__(self, master: tk.Misc):
        self.master = master
        self.win = tk.Toplevel(master)
        self.win.title("Declare Sessions")
        self.win.geometry("1250x630")

        self._build_ui()
        self._load_sessions()

    # ────────────────────────────── UI BUILD
    def _build_ui(self) -> None:
        outer = ttk.Frame(self.win)
        outer.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.tree = ttk.Treeview(outer, columns=self.COLS, show="headings")

        # column headings
        for col in self.COLS:
            self.tree.heading(col, text=col)

        # sensible widths / alignment
        self.tree.column("ID", width=60, anchor="center")
        self.tree.column("Stake", width=90, anchor="e")
        self.tree.column("Target", width=70, anchor="center")
        self.tree.column("Status", width=90, anchor="center")
        self.tree.column("Declared Runs", width=110, anchor="center")
        self.tree.column("Created At", width=150, anchor="center")

        # scrollbars
        ysb = ttk.Scrollbar(outer, orient="vertical", command=self.tree.yview)
        xsb = ttk.Scrollbar(outer, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=ysb.set, xscroll=xsb.set)

        # layout
        self.tree.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        outer.rowconfigure(0, weight=1)
        outer.columnconfigure(0, weight=1)

        # button row
        btns = ttk.Frame(self.win)
        btns.pack(pady=10)

        ttk.Button(btns, text="Declare…",  width=12,
                   command=self._declare).pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text="Undeclare", width=12,
                   command=self._undeclare).pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text="Refresh",   width=10,
                   command=self._load_sessions).pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text="Close",     width=10,
                   command=self.win.destroy).pack(side=tk.LEFT, padx=4)

    # ────────────────────────────── DATA
    def _load_sessions(self) -> None:
        """Fetch every session and populate the treeview."""
        self.tree.delete(*self.tree.get_children())

        with create_connection() as conn:
            cur = conn.cursor()
            cur.execute("""
                SELECT s.session_id,
                       m.team_a || ' vs ' || m.team_b       AS match_name,
                       s.bettor,
                       s.stake_amount,
                       s.target_runs,
                       s.status,
                       COALESCE(s.declared_runs, ''),
                       s.created_at
                  FROM sessions s
             LEFT JOIN matches  m ON m.match_id = s.match_id
              ORDER BY s.created_at DESC
            """)
            for row in cur.fetchall():
                self.tree.insert("", tk.END, values=row)

    # ────────────────────────────── HELPERS
    def _selected_id(self) -> int | None:
        sel = self.tree.selection()
        return int(self.tree.item(sel[0], "values")[0]) if sel else None

    # ────────────────────────────── DECLARE
    def _declare(self) -> None:
        sid = self._selected_id()
        if not sid:
            messagebox.showwarning("Select Session", "Choose a session to declare.")
            return

        runs = simpledialog.askinteger(
            "Declare Session",
            "Enter the *actual runs* for this session:",
            parent=self.win,
            minvalue=0
        )
        if runs is None:            # user cancelled
            return

        with create_connection() as conn:
            cur = conn.cursor()
            cur.execute("""
                UPDATE sessions
                   SET status        = 'Declared',
                       declared_runs = ?,
                       declared_at   = ?
                 WHERE session_id    = ?
            """, (runs, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), sid))
            conn.commit()

        self._load_sessions()
        messagebox.showinfo("Declared", f"Session #{sid} declared as {runs} runs.")

    # ────────────────────────────── UNDECLARE
    def _undeclare(self) -> None:
        sid = self._selected_id()
        if not sid:
            messagebox.showwarning("Select Session", "Choose a session first.")
            return

        if not messagebox.askyesno("Confirm", "Mark this session as *Pending* again?"):
            return

        with create_connection() as conn:
            cur = conn.cursor()
            cur.execute("""
                UPDATE sessions
                   SET status        = 'Pending',
                       declared_runs = NULL,
                       declared_at   = NULL
                 WHERE session_id    = ?
            """, (sid,))
            conn.commit()

        self._load_sessions()
        messagebox.showinfo("Undeclared", f"Session #{sid} is now Pending again.")
