"""A self‑contained Tkinter window for managing cricket‑related users and
commissions.  Drop this file next to an empty/ fresh *users.db* (it will be
created automatically).

Run directly to launch a demo:
    python user_manager_fixed.py
"""
from __future__ import annotations

from pathlib import Path
import json
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------
DB_PATH = Path(__file__).with_name("users.db")


def create_connection() -> sqlite3.Connection:
    """Returns a connection to the local SQLite DB (creates file if missing)."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_schema() -> None:
    conn = create_connection()
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            user_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            name      TEXT    NOT NULL,
            state_ref TEXT,
            phone     TEXT,
            refs      TEXT    -- JSON
        )
        """
    )
    conn.commit()
    conn.close()


_ensure_schema()

# ---------------------------------------------------------------------------
# Tk constants
# ---------------------------------------------------------------------------
STATE_OPTIONS = [
    "Ref A",
    "Ref B",
    "Ref C",
    "Umpire",
    "Third Umpire",
    "Match Referee",
    "Other",
]
PERCENT_OPTIONS = [f"{i}%" for i in range(1, 11)] + ["Other"]


class UserWindow(tk.Toplevel):
    """Window for managing user accounts and commissions."""

    # ---------------------------------------------------------------------
    # construction / UI ----------------------------------------------------
    # ---------------------------------------------------------------------

    def __init__(self, parent: tk.Misc):
        super().__init__(parent)
        self.title("User Manager")
        self.geometry("1700x680")
        self.parent = parent

        # --- internal data ----
        self.user_map: dict[str, int] = {}  # name -> id mapping
        self.selected_user_id: int | None = None
        self.vars: dict[str, tk.StringVar] = {}  # central registry of tk vars
        self.user_combos: list[ttk.Combobox] = []

        # --- build UI ----
        self._create_widgets()
        self._refresh_user_dropdowns()
        self._load_users()

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _new_var(self, name: str) -> tk.StringVar:  # centralised var factory
        var = tk.StringVar()
        self.vars[name] = var
        return var

    # ------------------------------------------------------------------
    # UI – top‑level layout
    # ------------------------------------------------------------------

    def _create_widgets(self):
        # Search bar ----------------------------------------------------
        search_frame = ttk.Frame(self)
        search_frame.pack(fill=tk.X, padx=10, pady=5)

        self.search_var = self._new_var("search")
        ttk.Entry(search_frame, textvariable=self.search_var, width=40).pack(
            side=tk.LEFT, padx=(0, 5)
        )
        ttk.Button(search_frame, text="Search", command=self._search_users).pack(side=tk.LEFT)
        ttk.Button(search_frame, text="Clear", command=self._clear_user_search).pack(
            side=tk.LEFT, padx=5
        )

        # Split between tree + form -----------------------------------
        content = ttk.Frame(self)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self._build_user_tree(content)
        self._build_user_form(content)

    # ------------------------------------------------------------------
    # USER LIST (TreeView)
    # ------------------------------------------------------------------

    def _build_user_tree(self, parent):
        frame = ttk.Frame(parent)
        frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        cols = ("ID", "Name", "State/Ref", "Phone", "Refs")
        self.users_tree = ttk.Treeview(
            frame, columns=cols, show="headings", selectmode="browse"
        )
        for col in cols:
            self.users_tree.heading(col, text=col)
            self.users_tree.column(col, width=130 if col != "Refs" else 230, anchor="center")

        y_scr = ttk.Scrollbar(frame, orient="vertical", command=self.users_tree.yview)
        x_scr = ttk.Scrollbar(frame, orient="horizontal", command=self.users_tree.xview)
        self.users_tree.configure(yscroll=y_scr.set, xscroll=x_scr.set)
        self.users_tree.grid(row=0, column=0, sticky="nsew")
        y_scr.grid(row=0, column=1, sticky="ns")
        x_scr.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.users_tree.bind("<<TreeviewSelect>>", self._on_user_tree_select)

    # ------------------------------------------------------------------
    # USER FORM ---------------------------------------------------------
    # ------------------------------------------------------------------

    def _build_user_form(self, parent):
        form = ttk.Frame(parent)
        form.pack(side=tk.LEFT, fill=tk.Y, padx=(10, 0))

        # ---------- basic info --------------------------------------
        ttk.Label(form, text="Name:").grid(row=0, column=0, sticky="e", pady=2)
        ttk.Entry(form, textvariable=self._new_var("name"), width=28).grid(
            row=0, column=1, columnspan=4, sticky="w"
        )

        ttk.Label(form, text="State/Ref:").grid(row=1, column=0, sticky="e", pady=2)
        state_var = self._new_var("state_ref")
        self.state_combo = ttk.Combobox(
            form, textvariable=state_var, values=STATE_OPTIONS, state="readonly", width=20
        )
        self.state_combo.grid(row=1, column=1, sticky="w")
        ttk.Entry(form, textvariable=self._new_var("state_extra"), width=10).grid(
            row=1, column=2, padx=(5, 0), sticky="w"
        )

        ttk.Label(form, text="Telephone:").grid(row=2, column=0, sticky="e", pady=2)
        ttk.Entry(form, textvariable=self._new_var("phone"), width=28).grid(
            row=2, column=1, columnspan=4, sticky="w"
        )

        # ---------- commission rows ---------------------------------
        commission_specs = [
            ("match_comm", "Match Commission:"),
            ("session_comm", "Session Commission:"),
            ("match_patti", "Match Patti:"),
            ("session_patti", "Session Patti:"),
        ]

        for idx, (prefix, label_text) in enumerate(commission_specs, start=3):
            ttk.Label(form, text=label_text).grid(row=idx, column=0, sticky="e", pady=2)

            # build *two* user/percent pairs per row  (1 & 2)
            for pair in (1, 2):
                user_var = self._new_var(f"{prefix}{pair}_user")
                percent_type_var = self._new_var(f"{prefix}{pair}_percent_type")
                percent_val_var = self._new_var(f"{prefix}{pair}_percent_val")

                user_cb = ttk.Combobox(
                    form,
                    textvariable=user_var,
                    values=[],  # filled later in _refresh_user_dropdowns()
                    state="readonly",
                    width=20,
                )
                user_cb.grid(row=idx, column=pair * 2 - 1, sticky="w")
                self.user_combos.append(user_cb)

                pct_cb = ttk.Combobox(
                    form,
                    textvariable=percent_type_var,
                    values=PERCENT_OPTIONS,
                    state="readonly",
                    width=8,
                )
                pct_cb.grid(row=idx, column=pair * 2, padx=(5, 0), sticky="w")

                # paired hidden/disabled Entry for numeric value
                pct_entry = ttk.Entry(
                    form, textvariable=percent_val_var, width=8, state="disabled"
                )
                pct_entry.grid(row=idx, column=pair * 2 + 1, sticky="w", padx=(2, 0))

                # selection handler enables entry for "Other"
                def _on_select(event, combo=pct_cb, entry=pct_entry, pval=percent_val_var):
                    sel = combo.get()
                    if sel == "Other":
                        pval.set("")
                        entry.config(state="normal")
                        entry.focus_set()
                    else:
                        pval.set(sel.rstrip("%"))
                        entry.config(state="disabled")

                pct_cb.bind("<<ComboboxSelected>>", _on_select)

        # --------- cutting reference & buttons ----------------------
        ttk.Label(form, text="Cutting Reference:").grid(row=7, column=0, sticky="e", pady=2)
        ttk.Entry(form, textvariable=self._new_var("cutting_ref"), width=20).grid(
            row=7, column=1, columnspan=4, sticky="w"
        )

        btns = ttk.Frame(form)
        btns.grid(row=8, column=0, columnspan=5, pady=10)
        ttk.Button(btns, text="Save / Update", command=self._save_user).pack(
            side=tk.LEFT, padx=5
        )
        ttk.Button(btns, text="Clear", command=self._clear_user_form).pack(side=tk.LEFT, padx=5)

    # ------------------------------------------------------------------
    # USER‑NAME list helpers (for commission Comboboxes)
    # ------------------------------------------------------------------

    def _refresh_user_dropdowns(self) -> None:
        names = self._get_user_names()
        for cb in self.user_combos:
            cb["values"] = names

    def _get_user_names(self) -> list[str]:
        conn = create_connection()
        cur = conn.cursor()
        cur.execute("SELECT user_id, name FROM users ORDER BY name COLLATE NOCASE")
        data = cur.fetchall()
        conn.close()

        # refresh mapping and return list of names
        self.user_map = {row["name"]: row["user_id"] for row in data}
        return list(self.user_map)

    # ------------------------------------------------------------------
    # Event: Treeview select  -------------------------------------------
    # ------------------------------------------------------------------

    def _on_user_tree_select(self, _):
        sel = self.users_tree.selection()
        if not sel:
            return
        values = self.users_tree.item(sel[0], "values")
        self.selected_user_id = int(values[0])

        # basic fields
        self.vars["name"].set(values[1])
        state_full = values[2] or ""
        base_state, extra_state = (state_full.split("|", 1) + [""])[:2]
        self.vars["state_ref"].set(base_state)
        self.vars["state_extra"].set(extra_state)
        self.vars["phone"].set(values[3])

        refs = json.loads(values[4]) if values[4] else {}

        def _apply_commission(prefix: str, idx: int, data: dict):
            user_var = self.vars[f"{prefix}{idx}_user"]
            pct_type_var = self.vars[f"{prefix}{idx}_percent_type"]
            pct_val_var = self.vars[f"{prefix}{idx}_percent_val"]

            if not data:
                user_var.set("")
                pct_type_var.set("")
                pct_val_var.set("")
                return

            # user
            user_id = data.get("user_id")
            user_name = next((n for n, uid in self.user_map.items() if uid == user_id), "")
            user_var.set(user_name)

            # percent
            pct = str(data.get("percentage", ""))
            if pct and f"{pct}%" in PERCENT_OPTIONS:
                pct_type_var.set(f"{pct}%")
                pct_val_var.set(pct)
            else:
                pct_type_var.set("Other")
                pct_val_var.set(pct)

        # iterate over commission types and two pairs each
        for key in ("match_comm", "session_comm", "match_patti", "session_patti"):
            items = refs.get(key, [])
            for i in (1, 2):
                _apply_commission(key, i, items[i - 1] if len(items) >= i else {})

        # cutting ref
        self.vars["cutting_ref"].set(refs.get("cutting_ref", ""))

    # ------------------------------------------------------------------
    # Tree search / clear
    # ------------------------------------------------------------------

    def _search_users(self):
        self._load_users(self.search_var.get().strip())

    def _clear_user_search(self):
        self.search_var.set("")
        self._load_users()

    # ------------------------------------------------------------------
    # Clear form
    # ------------------------------------------------------------------

    def _clear_user_form(self):
        self.selected_user_id = None
        for var in self.vars.values():
            var.set("")
        # refresh tree selection
        self.users_tree.selection_remove(self.users_tree.selection())

    # ------------------------------------------------------------------
    # SAVE/UPDATE user ----------------------------------------------------
    # ------------------------------------------------------------------

    def _save_user(self):
        # --- basic validation -----------------------------------------
        name = self.vars["name"].get().strip()
        if not name:
            messagebox.showwarning("Input", "Name is required.")
            return

        # commission equality validation (each pair must match) --------
        pair_specs = [
            ("match_comm", "Match Commission"),
            ("session_comm", "Session Commission"),
            ("match_patti", "Match Patti"),
            ("session_patti", "Session Patti"),
        ]
        errors: list[str] = []
        for prefix, label in pair_specs:
            p1 = self.vars[f"{prefix}1_percent_val"].get().strip()
            p2 = self.vars[f"{prefix}2_percent_val"].get().strip()
            # if p1 != p2:
            #     errors.append(f"{label} values must match")
        if errors:
            messagebox.showwarning("Input", "\n".join(errors))
            return

        # build refs JSON ---------------------------------------------
        def _collect_commission(prefix: str):
            out = []
            for idx in (1, 2):
                user_name = self.vars[f"{prefix}{idx}_user"].get().strip()
                pct = self.vars[f"{prefix}{idx}_percent_val"].get().strip()
                if user_name and pct:
                    if not pct.isdigit():
                        raise ValueError(f"Invalid percentage value: {pct}")
                    if user_name not in self.user_map:
                        raise ValueError(f"Invalid user selection: {user_name}")
                    out.append({"user_id": self.user_map[user_name], "percentage": float(pct)})
            return out

        try:
            refs = {
                "match_comm": _collect_commission("match_comm"),
                "session_comm": _collect_commission("session_comm"),
                "match_patti": _collect_commission("match_patti"),
                "session_patti": _collect_commission("session_patti"),
                "cutting_ref": self.vars["cutting_ref"].get().strip(),
            }
        except ValueError as exc:
            messagebox.showerror("Input", str(exc))
            return

        # state / phone ------------------------------------------------
        state_base = self.vars["state_ref"].get().strip()
        state_extra = self.vars["state_extra"].get().strip()
        state_full = f"{state_base}|{state_extra}" if state_extra else state_base
        phone = self.vars["phone"].get().strip()

        # DB write -----------------------------------------------------
        refs_json = json.dumps(refs, separators=(",", ":"))
        conn = create_connection()
        cur = conn.cursor()
        try:
            if self.selected_user_id:
                cur.execute(
                    """
                    UPDATE users
                       SET name=?, state_ref=?, phone=?, refs=?
                     WHERE user_id=?
                    """,
                    (name, state_full, phone, refs_json, self.selected_user_id),
                )
            else:
                cur.execute(
                    """
                    INSERT INTO users (name, state_ref, phone, refs)
                    VALUES (?, ?, ?, ?)
                    """,
                    (name, state_full, phone, refs_json),
                )
                self.selected_user_id = cur.lastrowid
            conn.commit()
        except Exception as exc:
            conn.rollback()
            messagebox.showerror("Error", f"Could not save user: {exc}")
            return
        finally:
            conn.close()

        # UI refresh ---------------------------------------------------
        self._refresh_user_dropdowns()
        self._load_users()
        self._clear_user_form()
        messagebox.showinfo("Success", "User saved.")

    # ------------------------------------------------------------------
    # load users into tree ----------------------------------------------
    # ------------------------------------------------------------------

    def _load_users(self, filter_text: str | None = None):
        conn = create_connection()
        cur = conn.cursor()
        if filter_text:
            cur.execute(
                """
                SELECT user_id, name, state_ref, phone, refs
                  FROM users
                 WHERE name LIKE ?
              ORDER BY user_id DESC
                """,
                (f"%{filter_text}%",),
            )
        else:
            cur.execute(
                "SELECT user_id, name, state_ref, phone, refs FROM users ORDER BY user_id DESC"
            )
        rows = cur.fetchall()
        conn.close()

        self.users_tree.delete(*self.users_tree.get_children())
        for row in rows:
            self.users_tree.insert(
                "", tk.END, values=(row["user_id"], row["name"], row["state_ref"], row["phone"], row["refs"])
            )

        # Keep dropdowns in sync with latest names
        self._refresh_user_dropdowns()


# ---------------------------------------------------------------------------
# quick demo / manual test ---------------------------------------------------
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()  # hide root: we only want the Toplevel
    UserWindow(root)
    root.mainloop()
