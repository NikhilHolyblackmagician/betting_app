"""
betting_app/app.py
────────────────────────────────────────────────────────────────────────
Refreshed “pretty” version — subtle theme tweaks, padding, fonts, zebra
striped tables, and consistent accelerators.

No new dependencies: everything uses the standard `ttk` widgets.
"""

from __future__ import annotations

import os
import shutil
import json
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

# local modules
from .team_window        import TeamWindow
from .transaction_window import TransactionWindow
from .report_window      import DeclareReportWindow
from .settle_window      import SettleWindow
from .user_window        import UserWindow


# ============================================================
# Database helpers
# ============================================================
DB_FILE = "betting.db"


def create_connection() -> sqlite3.Connection:  # noqa: N802
    return sqlite3.connect(DB_FILE)


def init_db() -> None:
    """Create base tables if they do not exist."""
    with create_connection() as conn:
        cur = conn.cursor()

        cur.execute("""
            CREATE TABLE IF NOT EXISTS matches (
                match_id INTEGER PRIMARY KEY,
                team_a   TEXT NOT NULL,
                team_b   TEXT NOT NULL,
                date     DATE,
                venue    TEXT,
                result   TEXT DEFAULT 'Pending'
            );
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS bets (
                bet_id     INTEGER PRIMARY KEY,
                match_id   INTEGER,
                bet_type   TEXT,
                selection  TEXT,
                stake      REAL,
                odds       REAL,
                outcome    TEXT DEFAULT 'Pending',
                FOREIGN KEY (match_id) REFERENCES matches(match_id)
            );
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id   INTEGER PRIMARY KEY,
                name      TEXT NOT NULL,
                state_ref TEXT,
                phone     TEXT,
                refs      TEXT
            );
        """)
        conn.commit()


init_db()

# ------------------------------------------------------------
BET_TYPES = ["Match Winner", "Top Scorer"]
STATE_OPTIONS = [
    "Ref A", "Ref B", "Ref C", "Umpire",
    "Third Umpire", "Match Referee", "Other",
]


# ============================================================
# Pretty helpers
# ============================================================
def beautify_style(root: tk.Tk) -> None:
    """Global ttk style tweaks (fonts, padding, zebra rows)."""
    style = ttk.Style(root)
    style.theme_use("clam")

    # global defaults
    style.configure(".", font=("Segoe UI", 10))
    style.configure("TButton", padding=6, font=("Segoe UI", 10, "bold"))
    style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
    style.map("TButton",
              background=[("pressed", "#d9d9d9"), ("active", "#e9e9e9")])

    # stripe rows
    style.configure("OddRow", background="#fafafa")
    style.configure("EvenRow", background="#f0f0f0")


def zebra_tree(tree: ttk.Treeview) -> None:
    """Apply alternating row colours to an existing Treeview."""
    for index, iid in enumerate(tree.get_children()):
        tag = "OddRow" if index % 2 else "EvenRow"
        tree.item(iid, tags=(tag,))


# ============================================================
# Main application
# ============================================================
class BettingApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Cricket Betting Manager")
        self.geometry("1150x780")
        beautify_style(self)

        # pop-ups
        self.user_win: tk.Toplevel | None = None

        self._build_menubar()
        self._build_notebook()
        self._bind_shortcuts()

    # ───────── Menubar ───────────────────────────────────────
    def _build_menubar(self) -> None:
        mbar = tk.Menu(self)

        entry = tk.Menu(mbar, tearoff=0)
        entry.add_command(label="User",  accelerator="F1",     command=self.open_user_entry)
        entry.add_command(label="Team",  accelerator="F2",     command=self.open_team_manager)
        entry.add_command(label="State/Ref", accelerator="Ctrl+S", command=self.open_state_entry)
        mbar.add_cascade(label="Entry", menu=entry)

        match = tk.Menu(mbar, tearoff=0)
        match.add_command(label="Transaction Entry", accelerator="F4",
                          command=self.open_transaction_entry)
        mbar.add_cascade(label="Match", menu=match)

        result = tk.Menu(mbar, tearoff=0)
        result.add_command(label="Declare Results", accelerator="F5",
                           command=self.open_declare_report)
        mbar.add_cascade(label="Result", menu=result)

        settling = tk.Menu(mbar, tearoff=0)
        settling.add_command(label="Final Settlement", accelerator="F6",
                             command=self.open_settle_window)
        mbar.add_cascade(label="Settling", menu=settling)

        tools = tk.Menu(mbar, tearoff=0)
        tools.add_command(label="Database Backup…", command=self._backup_database)
        mbar.add_cascade(label="Tools", menu=tools)

        mbar.add_command(label="Exit", command=self.quit)
        self.config(menu=mbar)

    # ───────── Notebook ─────────────────────────────────────
    def _build_notebook(self) -> None:
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill=tk.BOTH, expand=True)

        self.tab_match   = self._build_match_tab()
        self.tab_bet     = self._build_bet_tab()
        self.tab_results = self._build_results_tab()
        self.tab_reports = self._build_reports_tab()

    # ───────── Shortcuts ────────────────────────────────────
    def _bind_shortcuts(self):
        self.bind_all("<F1>",        lambda e: self.open_user_entry())
        self.bind_all("<F2>",        lambda e: self.open_team_manager())
        self.bind_all("<Control-s>", lambda e: self.open_state_entry())
        self.bind_all("<F4>",        lambda e: self.open_transaction_entry())
        self.bind_all("<F5>",        lambda e: self.open_declare_report())
        self.bind_all("<F6>",        lambda e: self.open_settle_window())

    # ========================================================
    #  TAB BUILDERS
    # ========================================================
    def _build_match_tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="Add Match")

        for r, txt in enumerate(("Team A:", "Team B:", "Date (YYYY-MM-DD):", "Venue:")):
            ttk.Label(tab, text=txt).grid(row=r, column=0, sticky="e", pady=5, padx=4)

        self.team_a_entry = ttk.Entry(tab, width=32)
        self.team_b_entry = ttk.Entry(tab, width=32)
        self.date_entry   = ttk.Entry(tab, width=32)
        self.venue_entry  = ttk.Entry(tab, width=32)

        for r, ent in enumerate((self.team_a_entry, self.team_b_entry,
                                 self.date_entry, self.venue_entry)):
            ent.grid(row=r, column=1, sticky="w", pady=5)

        ttk.Button(tab, text="Save Match", command=self.save_match)\
            .grid(row=4, column=0, columnspan=2, pady=12)

        tab.columnconfigure(1, weight=1)
        return tab

    def _build_bet_tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="Place Bet")

        labels = ("Match:", "Bet Type:", "Selection:", "Stake ($):", "Odds:")
        for r, txt in enumerate(labels):
            ttk.Label(tab, text=txt).grid(row=r, column=0, sticky="e", pady=5, padx=4)

        self.match_cb      = ttk.Combobox(tab, width=47, state="readonly", values=self._get_matches())
        self.bet_type_cb   = ttk.Combobox(tab, width=44, state="readonly", values=BET_TYPES)
        self.selection_ent = ttk.Entry(tab, width=47)
        self.stake_ent     = ttk.Entry(tab, width=18)
        self.odds_ent      = ttk.Entry(tab, width=18)

        widgets = (self.match_cb, self.bet_type_cb, self.selection_ent, self.stake_ent, self.odds_ent)
        for r, w in enumerate(widgets):
            w.grid(row=r, column=1, sticky="w", pady=5)

        ttk.Button(tab, text="Place Bet", command=self.save_bet)\
            .grid(row=5, column=0, columnspan=2, pady=12)

        tab.columnconfigure(1, weight=1)
        return tab

    def _build_results_tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="Results")

        for r, txt in enumerate(("Match:", "Actual Top Scorer:", "Winning Team:")):
            ttk.Label(tab, text=txt).grid(row=r, column=0, sticky="e", pady=5, padx=4)

        self.results_match_cb = ttk.Combobox(tab, width=47, state="readonly", values=self._get_matches())
        self.top_scorer_ent   = ttk.Entry(tab, width=47)
        self.winner_ent       = ttk.Entry(tab, width=47)

        self.results_match_cb.grid(row=0, column=1, sticky="w", pady=5)
        self.top_scorer_ent.grid(row=1, column=1, sticky="w", pady=5)
        self.winner_ent.grid(row=2, column=1, sticky="w", pady=5)

        ttk.Button(tab, text="Settle Bets", command=self.settle_bets)\
            .grid(row=3, column=0, columnspan=2, pady=12)
        tab.columnconfigure(1, weight=1)
        return tab

    def _build_reports_tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="Reports")

        # header buttons / headline
        topbar = ttk.Frame(tab); topbar.pack(fill=tk.X, pady=6)
        ttk.Button(topbar, text="Refresh Summary", command=self._refresh_profit_tables)\
            .pack(side=tk.LEFT, padx=6)
        self.profit_lbl = ttk.Label(topbar, text="", font=("Segoe UI", 12, "bold"))
        self.profit_lbl.pack(side=tk.LEFT)

        # split Profit | Loss
        tables = ttk.Frame(tab); tables.pack(fill=tk.BOTH, expand=True, padx=10, pady=6)
        ttk.Label(tables, text="Profit", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w")
        ttk.Label(tables, text="Loss",   font=("Segoe UI", 10, "bold")).grid(row=0, column=1, sticky="w")

        cols = ("Name", "Amount")
        self.profit_tv = ttk.Treeview(tables, columns=cols, show="headings", height=16, selectmode="browse")
        self.loss_tv   = ttk.Treeview(tables, columns=cols, show="headings", height=16, selectmode="browse")
        for tv in (self.profit_tv, self.loss_tv):
            for col in cols:
                tv.heading(col, text=col); tv.column(col, anchor="center", width=160)
        self.profit_tv.grid(row=1, column=0, sticky="nsew", padx=(0,8))
        self.loss_tv.grid(row=1, column=1, sticky="nsew")
        tables.rowconfigure(1, weight=1); tables.columnconfigure((0,1), weight=1)

        self._refresh_profit_tables()
        return tab

    # ─────────  Profit/Loss aggregator  ────────────────────────
    def _refresh_profit_tables(self):
        """Re-compute totals from bets + declared sessions."""
        profit: dict[str, float] = {}

        with create_connection() as conn:
            cur = conn.cursor()

            # bets
            for sel, stake, odds, outcome in cur.execute(
                "SELECT selection, stake, odds, outcome FROM bets WHERE outcome IN ('won','lost')"
            ):
                pl = stake * odds - stake if outcome == "won" else -stake
                profit[sel] = profit.get(sel, 0) + pl

            # sessions (status Declared)
            cur.execute("""
                SELECT bettor, declared_runs, target_runs, stake_amount
                  FROM sessions
                 WHERE status = 'Declared'
            """)
            for bettor, declared, target, stake in cur.fetchall():
                pl = stake * 0.8 if declared >= target else -1.2 * stake
                profit[bettor] = profit.get(bettor, 0) + pl

        # headline
        total = sum(profit.values())
        self.profit_lbl.config(text=f"Total Profit/Loss: ${total:,.2f}")

        # fill Profit / Loss trees
        for tv in (self.profit_tv, self.loss_tv):
            tv.delete(*tv.get_children())

        for name, amt in sorted(profit.items(), key=lambda x: x[0].lower()):
            target_tv = self.profit_tv if amt >= 0 else self.loss_tv
            target_tv.insert("", tk.END, values=(name, f"{amt:,.2f}"))

        zebra_tree(self.profit_tv); zebra_tree(self.loss_tv)

    # ========================================================
    #  COMMANDS
    # ========================================================
    # pop-ups
    def open_transaction_entry(self): TransactionWindow(self)
    def open_team_manager(self):      TeamWindow(self)
    def open_declare_report(self):    DeclareReportWindow(self)
    def open_settle_window(self):     SettleWindow(self)

    def open_user_entry(self):
        if self.user_win and self.user_win.winfo_exists():
            self.user_win.lift()
        else:
            self.user_win = UserWindow(self)

    # placeholder
    def open_team_entry(self):  messagebox.showinfo("Entry", "Team entry (future feature)")
    def open_state_entry(self): messagebox.showinfo("Entry", "State/Ref entry (future feature)")

    # match save
    def save_match(self) -> None:
        team_a, team_b = self.team_a_entry.get().strip(), self.team_b_entry.get().strip()
        if not (team_a and team_b):
            messagebox.showwarning("Input", "Both teams are required.")
            return

        try:
            with create_connection() as conn:
                conn.execute(
                    "INSERT INTO matches (team_a, team_b, date, venue) VALUES (?,?,?,?)",
                    (team_a, team_b, self.date_entry.get().strip(), self.venue_entry.get().strip()),
                )
                conn.commit()
            messagebox.showinfo("Success", "Match added.")
            self.match_cb["values"] = self.results_match_cb["values"] = self._get_matches()
            for ent in (self.team_a_entry, self.team_b_entry, self.date_entry, self.venue_entry):
                ent.delete(0, tk.END)
        except Exception as exc:
            messagebox.showerror("Error", str(exc))

    # bet save
    def save_bet(self) -> None:
        match_s = self.match_cb.get()
        if not match_s:
            messagebox.showwarning("Input", "Select a match.")
            return
        match_id = int(match_s.split(" - ")[0])

        try:
            stake = float(self.stake_ent.get()); odds = float(self.odds_ent.get())
        except ValueError:
            messagebox.showwarning("Input", "Stake and Odds must be numeric.")
            return
        if stake <= 0 or odds <= 0:
            messagebox.showwarning("Input", "Stake and Odds must be positive.")
            return

        try:
            with create_connection() as conn:
                conn.execute(
                    "INSERT INTO bets (match_id, bet_type, selection, stake, odds) VALUES (?,?,?,?,?)",
                    (match_id, self.bet_type_cb.get(), self.selection_ent.get(), stake, odds),
                )
                conn.commit()
            messagebox.showinfo("Success", "Bet placed.")
            for ent in (self.selection_ent, self.stake_ent, self.odds_ent): ent.delete(0, tk.END)
            self._load_bets()
        except Exception as exc:
            messagebox.showerror("Error", str(exc))

    # results settlement
    def settle_bets(self) -> None:
        match_s = self.results_match_cb.get()
        if not match_s:
            messagebox.showwarning("Input", "Choose a match.")
            return
        match_id = int(match_s.split(" - ")[0])
        winner   = self.winner_ent.get().strip()
        if not winner:
            messagebox.showwarning("Input", "Winning team required.")
            return
        top = self.top_scorer_ent.get().strip()

        try:
            with create_connection() as conn:
                cur = conn.cursor()
                cur.execute("UPDATE matches SET result=? WHERE match_id=?",
                            (f"{winner} won", match_id))
                cur.executescript(f"""
                    UPDATE bets
                       SET outcome = CASE WHEN selection = '{top}' THEN 'won' ELSE 'lost' END
                     WHERE match_id = {match_id} AND bet_type = 'Top Scorer';
                    UPDATE bets
                       SET outcome = CASE WHEN selection = '{winner}' THEN 'won' ELSE 'lost' END
                     WHERE match_id = {match_id} AND bet_type = 'Match Winner';
                """)
                conn.commit()
            messagebox.showinfo("Settled", "Bets settled.")
            self._load_bets(); self._update_profit_label()
            for ent in (self.top_scorer_ent, self.winner_ent): ent.delete(0, tk.END)
        except Exception as exc:
            messagebox.showerror("Error", str(exc))

    # util: fetch matches for comboboxes
    def _get_matches(self) -> list[str]:
        with create_connection() as conn:
            rows = conn.execute(
                "SELECT match_id, team_a || ' vs ' || team_b FROM matches ORDER BY match_id DESC"
            ).fetchall()
        return [f"{mid} - {txt}" for mid, txt in rows]

    # reports tab
    def _update_profit_label(self) -> None:
        with create_connection() as conn:
            total, = conn.execute("""
                SELECT COALESCE(SUM(
                    CASE outcome
                        WHEN 'won'  THEN stake * odds - stake
                        WHEN 'lost' THEN -stake
                        ELSE 0 END), 0)
                FROM bets
            """).fetchone()
        self.profit_lbl.config(text=f"Total Profit/Loss: ${total:,.2f}")

    def _load_bets(self):
        with create_connection() as conn:
            rows = conn.execute("""
                SELECT b.bet_id,
                       m.team_a || ' vs ' || m.team_b,
                       b.bet_type, b.selection, b.outcome
                  FROM bets b
                  JOIN matches m ON b.match_id = m.match_id
              ORDER BY b.bet_id DESC
            """).fetchall()

        self.bets_tv.delete(*self.bets_tv.get_children())
        for row in rows:
            iid = self.bets_tv.insert("", tk.END, values=row)
        zebra_tree(self.bets_tv)

    # backup
    def _backup_database(self):
        if not os.path.exists(DB_FILE):
            messagebox.showerror("Backup", "Database not found.")
            return
        fname = f"betting_backup_{datetime.now():%Y%m%d_%H%M%S}.db"
        try:
            shutil.copy(DB_FILE, fname)
            messagebox.showinfo("Backup", f"Copied → {fname}")
        except Exception as exc:
            messagebox.showerror("Backup", str(exc))


# ============================================================
# RUN
# ============================================================
if __name__ == "__main__":
    BettingApp().mainloop()
