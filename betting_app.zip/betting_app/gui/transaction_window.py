"""
transaction_window.py
────────────────────────────────────────────────────────────────────────
Full source for the “Transaction Entry” window, now with :

1.  A **sessions** table bootstrap (created on import if it doesn’t exist).
2.  `_save_session()` that inserts rows into that table.
3.  The previously-requested UI tweaks (wider Amount fields, 80 % / –120 % ladder).
"""

import sqlite3
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from database.db import create_connection   # betting.db connector

# ───────────────────────────────────────────────────────────────
#  users.db helper
# ───────────────────────────────────────────────────────────────
USERS_DB = Path(__file__).with_name("users.db")


def get_user_names() -> list[str]:
    """Return the list of user names stored in users.db (alphabetical, case-insensitive)."""
    if not USERS_DB.exists():
        return []
    with sqlite3.connect(USERS_DB) as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT name FROM users ORDER BY name COLLATE NOCASE")
        return [row["name"] for row in cur.fetchall()]


# ───────────────────────────────────────────────────────────────
#  sessions table bootstrap
# ───────────────────────────────────────────────────────────────
def _ensure_sessions_table() -> None:
    """Create the *sessions* table once, if it does not yet exist."""
    with create_connection() as conn:
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                session_id     INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id       INTEGER NOT NULL,
                bettor         TEXT    NOT NULL,
                rate_pct       REAL    NOT NULL,
                stake_amount   REAL    NOT NULL,
                target_runs    INTEGER NOT NULL,
                status         TEXT    NOT NULL DEFAULT 'Pending',  -- Pending | Declared
                declared_runs  INTEGER,
                created_at     TEXT    NOT NULL,
                declared_at    TEXT,
                FOREIGN KEY (match_id) REFERENCES matches(match_id)
            )
            """
        )
        conn.commit()


# run bootstrap once when the module is imported
_ensure_sessions_table()

# ═══════════════════════════════════════════════════════════════
class TransactionWindow:
    """Betting / exposure manager with resizable split view."""

    # ───────── INIT ──────────────────────────────────────────
    def __init__(self, master: tk.Misc):
        self.master = master
        self.window = tk.Toplevel(master)
        self.window.title("Transaction Entry")
        self.window.geometry("1280x860")
        self.window.minsize(1100, 720)

        # adopt a modern ttk theme
        style = ttk.Style(self.window)
        style.theme_use("clam")
        style.configure("Treeview.Heading", font=("Helvetica", 10, "bold"))
        style.configure("TButton", padding=4)

        # state holders
        self.matches: list[tuple[int, str]] = []
        self.current_match_idx = -1
        self.current_match_id: int | None = None
        self.team_a = self.team_b = ""
        self.user_list: list[str] = []

        self._build_ui()
        self._load_matches()
        self._refresh_user_combo()

    # ───────── UI BUILD ─────────────────────────────────────
    def _build_ui(self):
        pad = dict(padx=10, pady=4)

        # 1️⃣  Header (navigation) ────────────────────────────
        hdr = ttk.Frame(self.window)
        hdr.pack(fill=tk.X, **pad)

        self.prev_btn = ttk.Button(hdr, text="◀", width=3, command=self._prev_match)
        self.prev_btn.pack(side=tk.LEFT)

        ttk.Label(hdr, text="Match:").pack(side=tk.LEFT, padx=6)
        self.match_cb = ttk.Combobox(hdr, state="readonly", width=46)
        self.match_cb.pack(side=tk.LEFT)
        self.match_cb.bind("<<ComboboxSelected>>", self._on_match_select)

        self.next_btn = ttk.Button(hdr, text="▶", width=3, command=self._next_match)
        self.next_btn.pack(side=tk.LEFT, padx=6)

        self.team_lbl = ttk.Label(hdr, text="", font=("Helvetica", 12, "bold"))
        self.team_lbl.pack(side=tk.LEFT, padx=20)

        # 2️⃣  Totals row ─────────────────────────────────────
        totals = ttk.Frame(self.window)
        totals.pack(fill=tk.X, **pad)

        self.team_a_tot = tk.StringVar(self.window, "")
        self.team_b_tot = tk.StringVar(self.window, "")
        ttk.Label(totals, textvariable=self.team_a_tot,
                  font=("Helvetica", 10, "bold")).pack(side=tk.LEFT, padx=(0, 16))
        ttk.Label(totals, textvariable=self.team_b_tot,
                  font=("Helvetica", 10, "bold")).pack(side=tk.LEFT)

        self.avg_k = tk.StringVar(self.window, "0.00")
        self.avg_l = tk.StringVar(self.window, "0.00")
        ttk.Label(totals, text="│ Avg K(+):").pack(side=tk.LEFT, padx=(30, 4))
        ttk.Label(totals, textvariable=self.avg_k).pack(side=tk.LEFT)
        ttk.Label(totals, text="Avg L(–):").pack(side=tk.LEFT, padx=(20, 4))
        ttk.Label(totals, textvariable=self.avg_l).pack(side=tk.LEFT)

        # 3️⃣  Action buttons ────────────────────────────────
        act = ttk.Frame(self.window)
        act.pack(fill=tk.X, **pad)
        ttk.Button(act, text="Delete", width=10, command=self._delete_txn).pack(side=tk.LEFT)
        ttk.Button(act, text="Modify", width=10, command=self._modify_txn).pack(side=tk.LEFT, padx=6)

        # 4️⃣  PanedWindow split ─────────────────────────────
        paned = ttk.PanedWindow(self.window, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, **pad)

        # left pane: transactions tree
        left = ttk.Frame(paned)
        paned.add(left, weight=3)
        tx_cols = ("ID", "Type", "Amt", "Rate%", "Time", "Desc")
        self.tree = ttk.Treeview(left, columns=tx_cols, show="headings")
        for c in tx_cols:
            self.tree.heading(c, text=c)
        self.tree.column("ID", width=60, anchor="center")
        self.tree.column("Type", width=45, anchor="center")
        self.tree.column("Amt", width=90, anchor="e")
        self.tree.column("Rate%", width=60, anchor="center")
        self.tree.column("Time", width=150, anchor="center")
        self.tree.column("Desc", width=340)
        self.tree.grid(row=0, column=0, sticky="nsew")
        ttk.Scrollbar(left, orient="vertical", command=self.tree.yview).grid(row=0, column=1, sticky="ns")
        left.rowconfigure(0, weight=1)
        left.columnconfigure(0, weight=1)
        self.tree.configure(yscroll=lambda *a: left.children['!scrollbar'].set(*a))

        # right pane: exposure + session
        right = ttk.Frame(paned)
        paned.add(right, weight=2)

        # Exposure box
        exp_box = ttk.LabelFrame(right, text="Exposure")
        exp_box.pack(fill=tk.BOTH, expand=False, pady=(0, 10))
        self.exp_tree = ttk.Treeview(exp_box, columns=("Person", "For", "Against"),
                                     show="headings", height=9, selectmode="browse")
        for h, w in (("Person", 115), ("For", 90), ("Against", 90)):
            self.exp_tree.heading(h, text=h)
            self.exp_tree.column(h, width=w, anchor="center")
        self.exp_tree.grid(row=0, column=0, sticky="nsew")
        ttk.Scrollbar(exp_box, orient="vertical", command=self.exp_tree.yview).grid(row=0, column=1, sticky="ns")
        self.exp_tree.bind("<<TreeviewSelect>>", self._on_exp_select)

        # Session box
        sess = ttk.LabelFrame(right, text="Session")
        sess.pack(fill=tk.BOTH, expand=True)
        pad_s = dict(padx=6, pady=3)

        self.session_person = ttk.Label(sess, text="(select bettor above)", font=("Helvetica", 9, "italic"))
        self.session_person.grid(row=0, column=0, columnspan=6, sticky="w", **pad_s)

        # Row 1 — Name ▏ Rate% ▏ Amount
        ttk.Label(sess, text="Name:").grid(row=1, column=0, sticky="e", **pad_s)
        self.session_name = ttk.Entry(sess, width=18)
        self.session_name.grid(row=1, column=1, sticky="w", **pad_s)

        ttk.Label(sess, text="Rate %:").grid(row=1, column=2, sticky="e", **pad_s)
        self.session_rate = ttk.Entry(sess, width=6)
        self.session_rate.insert(0, "100")
        self.session_rate.grid(row=1, column=3, sticky="w", **pad_s)

        ttk.Label(sess, text="Amount:").grid(row=1, column=4, sticky="e", **pad_s)
        self.session_amount = ttk.Entry(sess, width=18)
        self.session_amount.grid(row=1, column=5, sticky="w", **pad_s)

        # Row 2 — Target ▏ buttons
        ttk.Label(sess, text="Target Runs:").grid(row=2, column=0, sticky="e", **pad_s)
        self.session_runs = ttk.Entry(sess, width=6)
        self.session_runs.grid(row=2, column=1, sticky="w", **pad_s)

        ttk.Button(sess, text="Generate Sheet", command=self._make_sheet).grid(row=2, column=2, sticky="w", **pad_s)
        ttk.Button(sess, text="Save", command=self._save_session).grid(row=2, column=3, sticky="w", **pad_s)

        # price ladder
        sheet_box = ttk.Frame(sess)
        sheet_box.grid(row=3, column=0, columnspan=6, sticky="nsew", **pad_s)
        self.sheet_tree = ttk.Treeview(sheet_box, columns=("Run", "Price"), show="headings", height=6)
        self.sheet_tree.heading("Run", text="Run")
        self.sheet_tree.heading("Price", text="Price")
        self.sheet_tree.column("Run", width=60, anchor="center")
        self.sheet_tree.column("Price", width=90, anchor="e")
        self.sheet_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        ttk.Scrollbar(sheet_box, orient="vertical", command=self.sheet_tree.yview).pack(side=tk.RIGHT, fill=tk.Y)
        sess.rowconfigure(3, weight=1)
        sess.columnconfigure(5, weight=1)

        # 5️⃣  New-Bet panel
        nb = ttk.LabelFrame(self.window, text="New Bet")
        nb.pack(fill=tk.X, **pad)

        self.person_var = tk.StringVar(self.window)
        self.person_cb = ttk.Combobox(nb, textvariable=self.person_var, width=18,
                                      postcommand=self._refresh_user_combo)
        self.team_var = tk.StringVar(self.window)
        self.team_cb = ttk.Combobox(nb, textvariable=self.team_var, state="readonly", width=16)
        self.amount_ent = ttk.Entry(nb, width=12)
        self.rate_ent = ttk.Entry(nb, width=6)
        self.rate_ent.insert(0, "50")
        self.type_var = tk.StringVar(self.window, value="K")
        self.type_cb = ttk.Combobox(nb, textvariable=self.type_var, state="readonly", width=4, values=("K", "L"))

        for i, (lbl, w) in enumerate((("Person", self.person_cb), ("Team", self.team_cb),
                                      ("Amt", self.amount_ent), ("Rate%", self.rate_ent),
                                      ("Type", self.type_cb))):
            ttk.Label(nb, text=f"{lbl}:").grid(row=0, column=i * 2, sticky="e", padx=3)
            w.grid(row=0, column=i * 2 + 1, sticky="w", padx=3)
        ttk.Button(nb, text="Save", command=self._save_bet).grid(row=0, column=12, padx=18)

    # ───────── data-refresh helpers ───────────────────────────
    def _refresh_user_combo(self):
        self.user_list = get_user_names()
        self.person_cb["values"] = self.user_list

    def _load_matches(self):
        with create_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT match_id, team_a || ' vs ' || team_b FROM matches ORDER BY date DESC")
            self.matches = cur.fetchall()
        self.match_cb["values"] = [f"{mid} - {nm}" for mid, nm in self.matches]
        if self.matches:
            self.current_match_idx = 0
            self.match_cb.current(0)
            self._on_match_select()
        self._update_nav()

    # nav
    def _update_nav(self):
        self.prev_btn["state"] = tk.NORMAL if self.current_match_idx > 0 else tk.DISABLED
        self.next_btn["state"] = tk.NORMAL if self.current_match_idx < len(self.matches) - 1 else tk.DISABLED

    def _prev_match(self):
        if self.current_match_idx > 0:
            self.current_match_idx -= 1
            self.match_cb.current(self.current_match_idx)
            self._on_match_select()
            self._update_nav()

    def _next_match(self):
        if self.current_match_idx < len(self.matches) - 1:
            self.current_match_idx += 1
            self.match_cb.current(self.current_match_idx)
            self._on_match_select()
            self._update_nav()

    # load a match’s data
    def _on_match_select(self, *_):
        if not self.match_cb.get():
            return
        self.current_match_id = int(self.match_cb.get().split(" - ")[0])

        with create_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT team_a, team_b FROM matches WHERE match_id=?", (self.current_match_id,))
            self.team_a, self.team_b = cur.fetchone()

            cur.execute(
                """
                SELECT transaction_id, type, amount, timestamp, description
                  FROM transactions
                 WHERE match_id = ?
              ORDER BY timestamp DESC
                """,
                (self.current_match_id,),
            )
            rows = cur.fetchall()

        self.team_lbl.config(text=f"{self.team_a} vs {self.team_b}")
        self.team_cb["values"] = (self.team_a, self.team_b)
        self._refresh_tables(rows)

    # table builders
    def _refresh_tables(self, rows):
        self.tree.delete(*self.tree.get_children())
        self.exp_tree.delete(*self.exp_tree.get_children())
        self.sheet_tree.delete(*self.sheet_tree.get_children())
        self.session_person.config(text="(select bettor above)")

        pos_a = neg_a = pos_b = neg_b = 0.0
        pos_vals, neg_vals = [], []

        for tid, typ, amt, ts, desc in rows:
            person, team, rate = self._parse_desc(desc)
            self.tree.insert("", tk.END, values=(tid, typ, f"{amt:.2f}", f"{rate:.1f}", ts, desc))
            if not person:
                continue
            pos = amt * rate / 100
            neg = -amt
            if team == self.team_a:
                pos_a += pos
                neg_b += neg
            else:
                pos_b += pos
                neg_a += neg
            pos_vals.append(pos)
            neg_vals.append(abs(neg))
            self.exp_tree.insert("", tk.END, values=(person, f"{pos:.2f}", f"{neg:.2f}"))

        self.team_a_tot.set(f"{self.team_a}  +{pos_a:.2f} / {neg_a:.2f}")
        self.team_b_tot.set(f"{self.team_b}  +{pos_b:.2f} / {neg_b:.2f}")
        self.avg_k.set(f"{sum(pos_vals)/len(pos_vals):.2f}" if pos_vals else "0.00")
        self.avg_l.set(f"{sum(neg_vals)/len(neg_vals):.2f}" if neg_vals else "0.00")

    def _on_exp_select(self, _):
        sel = self.exp_tree.selection()
        if sel:
            name = self.exp_tree.item(sel[0], "values")[0]
            self.session_person.config(text=f"Bettor: {name}")

    # price ladder
    def _make_sheet(self):
        if not self.session_person.cget("text").startswith("Bettor:"):
            messagebox.showinfo("Session", "Select a bettor in the Exposure table.")
            return
        try:
            stake = float(self.session_amount.get())
            target = int(self.session_runs.get())
            if stake <= 0 or target <= 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning("Input", "Amount and Runs must be positive numbers.")
            return

        neg_price, pos_price = -stake * 1.20, stake * 0.80

        self.sheet_tree.delete(*self.sheet_tree.get_children())
        for n in range(1, target + 1):
            price = pos_price if n >= target else neg_price
            self.sheet_tree.insert("", tk.END, values=(n, f"{price:.2f}"))

    # ───────── save SESSION (now persists) ─────────────────────
    def _save_session(self):
        name = self.session_name.get().strip()
        rate_s = self.session_rate.get().strip()
        amt_s = self.session_amount.get().strip()
        runs_s = self.session_runs.get().strip()

        if not (name and rate_s and amt_s and runs_s):
            messagebox.showerror("Session", "Name, Rate, Amount, and Runs are required.")
            return
        try:
            rate = float(rate_s)
            stake = float(amt_s)
            runs = int(runs_s)
            if rate <= 0 or stake <= 0 or runs <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Session", "Rate, Amount and Runs must be positive numbers.")
            return

        created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            with create_connection() as conn:
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO sessions
                          (match_id, bettor, rate_pct, stake_amount,
                           target_runs, created_at)
                    VALUES (?,?,?,?,?,?)
                    """,
                    (self.current_match_id, name, rate, stake, runs, created),
                )
                conn.commit()
        except Exception as exc:
            messagebox.showerror("Database", f"Could not save session:\n{exc}")
            return

        messagebox.showinfo("Session saved", f"Session stored for {name} — target {runs} runs.")
        # clear inputs
        self.session_name.delete(0, tk.END)
        self.session_rate.delete(0, tk.END)
        self.session_rate.insert(0, "100")
        self.session_amount.delete(0, tk.END)
        self.session_runs.delete(0, tk.END)
        self.session_person.config(text="(select bettor above)")
        self.sheet_tree.delete(*self.sheet_tree.get_children())

    # ───────── save new bet ───────────────────────────────────
    def _save_bet(self):
        person = self.person_var.get().strip()
        team = self.team_var.get()
        amt_s = self.amount_ent.get().strip()
        rate_s = self.rate_ent.get().strip()
        typ = self.type_var.get()

        if not (person and team and amt_s and rate_s):
            messagebox.showerror("Validation", "All fields are required")
            return
        try:
            amount = float(amt_s)
            rate = float(rate_s)
        except ValueError:
            messagebox.showerror("Validation", "Amount and Rate must be numeric")
            return

        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        desc = f"Bet by {person} on {team} @ {rate:.1f}%"

        with create_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                """
                INSERT INTO transactions (match_id, type, amount, timestamp, description)
                VALUES (?,?,?,?,?)
                """,
                (self.current_match_id, typ, amount, ts, desc),
            )
            conn.commit()

        if person not in self.user_list:
            self.user_list.append(person)
            self.user_list.sort()
            self.person_cb["values"] = self.user_list

        # reset
        self.person_var.set("")
        self.team_var.set("")
        self.amount_ent.delete(0, tk.END)
        self.rate_ent.delete(0, tk.END)
        self.rate_ent.insert(0, "50")
        self.type_var.set("K")
        self._on_match_select()

    # ───────── misc helpers ───────────────────────────────────
    def _selected_txn_id(self):
        sel = self.tree.selection()
        return int(self.tree.item(sel[0], "values")[0]) if sel else None

    def _delete_txn(self):
        tid = self._selected_txn_id()
        if tid and messagebox.askyesno("Confirm", "Delete selected transaction?"):
            with create_connection() as conn:
                cur = conn.cursor()
                cur.execute("DELETE FROM transactions WHERE transaction_id=?", (tid,))
                conn.commit()
            self._on_match_select()

    def _modify_txn(self):
        tid = self._selected_txn_id()
        if not tid:
            return

        with create_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT amount, description FROM transactions WHERE transaction_id=?", (tid,))
            amount, desc = cur.fetchone()

        edit = tk.Toplevel(self.window)
        edit.title("Modify Transaction")
        ttk.Label(edit, text="Amount:").grid(row=0, column=0, padx=6, pady=6)
        amt_ent = ttk.Entry(edit, width=12)
        amt_ent.insert(0, amount)
        amt_ent.grid(row=0, column=1)
        ttk.Label(edit, text="Description:").grid(row=1, column=0, padx=6, pady=6)
        desc_ent = ttk.Entry(edit, width=40)
        desc_ent.insert(0, desc)
        desc_ent.grid(row=1, column=1)

        def commit():
            try:
                new_amt = float(amt_ent.get())
            except ValueError:
                messagebox.showerror("Error", "Amount must be numeric")
                return
            new_desc = desc_ent.get().strip()
            with create_connection() as conn2:
                cur2 = conn2.cursor()
                cur2.execute(
                    "UPDATE transactions SET amount=?, description=? WHERE transaction_id=?",
                    (new_amt, new_desc, tid),
                )
                conn2.commit()
            edit.destroy()
            self._on_match_select()

        ttk.Button(edit, text="Save", command=commit).grid(row=2, column=0, columnspan=2, pady=10)

    @staticmethod
    def _parse_desc(desc: str):
        """Parse “Bet by X on TEAM @ RATE%” and return (person, team, rate)."""
        try:
            p = desc.split("Bet by ")[1].split(" on ")[0]
            t = desc.split(" on ")[1].split(" @ ")[0]
            r = float(desc.split(" @ ")[1].rstrip("%"))
            return p, t, r
        except Exception:
            return None, None, 0.0
