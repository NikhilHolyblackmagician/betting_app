"""
settle_window.py
────────────────────────────────────────────────────────────────────────
Final-settlement window for the Cricket Betting Manager.

Key points
──────────
• Left pane lists every *Declared* session plus every bet that is already
  won / lost (no “Pending”).
  Columns:  Type | ID | Match | Name/Selection | Date

• “Auto-connect” checkbox (default ON) expands your selection:
  – All rows that share the **same match** *and* **same calendar date**
    are selected together.
  – Recursion-guard prevents infinite event loops.

• Right pane splits the combined profit & loss by person:
  *Profit* table (positive) and *Loss* table (negative).

• “Settle Selected” button (stub): in a real app you would mark those
  sessions / bets as `settled = 1`; here it simply removes them from view.

Assumptions
───────────
Sessions table from `transaction_window.py` exists.
Profit rules:
    session  = +0.8×stake  if declared_runs ≥ target_runs, else −1.2×stake
    bet      = stake*odds − stake  (won)  |  −stake (lost)

Adjust SQL as needed if you store explicit created-at timestamps for bets.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox
from database.db import create_connection


# ───────────────────────────────────────────────────────────────
#  Profit helpers
# ───────────────────────────────────────────────────────────────
def session_profit(declared: int, target: int, stake: float) -> float:
    """80 % win, –120 % loss."""
    return stake * 0.8 if declared >= target else -1.2 * stake


def bet_profit(outcome: str, stake: float, odds: float) -> float:
    """Return P/L for a single bet row."""
    if outcome == "won":
        return stake * odds - stake
    if outcome == "lost":
        return -stake
    return 0.0


# ═══════════════════════════════════════════════════════════════
class SettleWindow(tk.Toplevel):
    """UI for aggregating and final-settling sessions + bets."""

    LEFT_COLS  = ("Type", "ID", "Match", "Name / Selection", "Date")
    RIGHT_COLS = ("Name", "Amount")

    # ───────── INIT ───────────────────────────────────────────
    def __init__(self, master: tk.Misc):
        super().__init__(master)
        self.title("Final Settlement")
        self.geometry("1200x650")

        # store extra data for each row (iid → tuple)
        self.meta: dict[str, tuple] = {}
        self._in_refresh = False      # recursion guard

        self._build_ui()
        self._load_rows()

    # ───────── UI BUILD ───────────────────────────────────────
    def _build_ui(self) -> None:
        paned = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # LEFT pane ----------------------------------------------------
        left = ttk.Frame(paned); paned.add(left, weight=3)

        self.auto_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(left, text="Auto-connect by match & date",
                        variable=self.auto_var).pack(anchor="w")

        self.left_tv = ttk.Treeview(
            left, columns=self.LEFT_COLS, show="headings",
            height=20, selectmode="extended"
        )
        for col in self.LEFT_COLS:
            self.left_tv.heading(col, text=col)
        self.left_tv.column("Type", width=70, anchor="center")
        self.left_tv.column("ID",   width=60, anchor="center")
        self.left_tv.column("Date", width=90, anchor="center")
        self.left_tv.pack(fill=tk.BOTH, expand=True)
        self.left_tv.bind("<<TreeviewSelect>>", self._refresh_right)

        # RIGHT pane ---------------------------------------------------
        right = ttk.Frame(paned); paned.add(right, weight=2)

        ttk.Label(right, text="Profit", font=("Segoe UI", 10, "bold"))\
            .grid(row=0, column=0, sticky="w")
        ttk.Label(right, text="Loss", font=("Segoe UI", 10, "bold"))\
            .grid(row=0, column=1, sticky="w")

        self.profit_tv = ttk.Treeview(right, columns=self.RIGHT_COLS,
                                      show="headings", height=18, selectmode="none")
        self.loss_tv   = ttk.Treeview(right, columns=self.RIGHT_COLS,
                                      show="headings", height=18, selectmode="none")
        for tv in (self.profit_tv, self.loss_tv):
            for col in self.RIGHT_COLS:
                tv.heading(col, text=col)
                tv.column(col, anchor="center", width=120)

        self.profit_tv.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        self.loss_tv.grid(row=1, column=1, sticky="nsew")
        right.rowconfigure(1, weight=1)
        right.columnconfigure((0, 1), weight=1)

        # bottom buttons
        bbar = ttk.Frame(self); bbar.pack(pady=6)
        ttk.Button(bbar, text="Settle Selected", command=self._settle)\
            .pack(side=tk.LEFT, padx=6)
        ttk.Button(bbar, text="Close", command=self.destroy)\
            .pack(side=tk.LEFT, padx=6)

    # ───────── LOAD data ───────────────────────────────────────
    def _load_rows(self) -> None:
        """Populate left tree with declared sessions + decided bets."""
        self.left_tv.delete(*self.left_tv.get_children())
        self.meta.clear()

        with create_connection() as conn:
            cur = conn.cursor()

            # Sessions (status='Declared')
            cur.execute("""
                SELECT s.session_id,
                       m.team_a || ' vs ' || m.team_b,
                       s.bettor,
                       DATE(s.created_at),
                       s.declared_runs, s.target_runs, s.stake_amount,
                       m.match_id
                  FROM sessions s
                  JOIN matches  m ON m.match_id = s.match_id
                 WHERE s.status = 'Declared'
            """)
            for sid, match, bettor, dstr, declared, target, stake, mid in cur.fetchall():
                iid = f"S{sid}"
                self.left_tv.insert("", tk.END,
                                    iid=iid,
                                    values=("Session", sid, match, bettor, dstr),
                                    tags=(f"M{mid}", dstr))
                self.meta[iid] = ("Session", declared, target, stake, bettor)

            # Bets with outcome
            cur.execute("""
                SELECT b.bet_id,
                       m.team_a || ' vs ' || m.team_b,
                       b.selection,
                       DATE(bet_id, 'unixepoch'),      -- fallback date
                       b.outcome, b.stake, b.odds,
                       m.match_id
                  FROM bets b
                  JOIN matches m ON m.match_id = b.match_id
                 WHERE b.outcome IN ('won','lost')
            """)
            for bid, match, sel, dstr, outcome, stake, odds, mid in cur.fetchall():
                iid = f"B{bid}"
                self.left_tv.insert("", tk.END,
                                    iid=iid,
                                    values=("Bet", bid, match, sel, dstr),
                                    tags=(f"M{mid}", dstr))
                self.meta[iid] = ("Bet", outcome, stake, odds, sel)

    # ───────── REFRESH right pane ──────────────────────────────
    def _refresh_right(self, _evt=None):
        # guard against recursion
        if self._in_refresh:
            return
        self._in_refresh = True
        try:
            # auto-connect: add all rows with same (match, date) tags
            if self.auto_var.get() and self.left_tv.selection():
                first = self.left_tv.selection()[0]
                match_tag, date_tag = self.left_tv.item(first, "tags")
                linked = [
                    iid for iid in self.left_tv.get_children()
                    if {match_tag, date_tag}.issubset(self.left_tv.item(iid, "tags"))
                ]
                if set(linked) != set(self.left_tv.selection()):
                    self.left_tv.selection_set(linked)

            # aggregate profit/loss per name
            pl_map: dict[str, float] = {}
            for iid in self.left_tv.selection():
                meta = self.meta[iid]
                if meta[0] == "Session":
                    _, declared, target, stake, name = meta
                    amt = session_profit(int(declared), int(target), float(stake))
                else:  # Bet
                    _, outcome, stake, odds, name = meta
                    amt = bet_profit(outcome, float(stake), float(odds))
                pl_map[name] = pl_map.get(name, 0) + amt

            # rebuild right tables
            self.profit_tv.delete(*self.profit_tv.get_children())
            self.loss_tv.delete(*self.loss_tv.get_children())
            for name, amt in sorted(pl_map.items(), key=lambda x: x[0].lower()):
                tv = self.profit_tv if amt >= 0 else self.loss_tv
                tv.insert("", tk.END, values=(name, f"{amt:.2f}"))
        finally:
            self._in_refresh = False

    # ───────── SETTLE (stub) ───────────────────────────────────
    def _settle(self):
        if not self.left_tv.selection():
            messagebox.showinfo("Settle", "No rows selected.")
            return
        if not messagebox.askyesno("Confirm", "Mark selected rows as settled?"):
            return

        # ⚠️  REAL APP: update DB here (e.g. sessions.status = 'Settled')
        # For now we simply remove rows from UI
        for iid in list(self.left_tv.selection()):
            self.left_tv.delete(iid)
            self.meta.pop(iid, None)

        self._refresh_right()
        messagebox.showinfo("Settle", "Rows marked as settled (stub).")
