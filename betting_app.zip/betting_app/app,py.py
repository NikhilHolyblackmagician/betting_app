from gui.main_app import BettingApp

if __name__ == "__main__":
    app = BettingApp()
    app.mainloop()