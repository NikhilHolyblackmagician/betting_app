import os
import json
import shutil
import sqlite3
import tkinter as tk
from datetime import datetime
from tkinter import ttk, messagebox

# ============================================================
# Database Setup
# ============================================================

DB_FILE = "betting.db"


def create_connection() -> sqlite3.Connection:
    """Return a connection to the local SQLite database."""
    return sqlite3.connect(DB_FILE)


def init_db() -> None:
    """Create tables for matches, bets and users if they do not exist."""
    conn = create_connection()
    cursor = conn.cursor()

    # matches
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS matches (
            match_id INTEGER PRIMARY KEY,
            team_a   TEXT NOT NULL,
            team_b   TEXT NOT NULL,
            date     DATE,
            venue    TEXT,
            result   TEXT DEFAULT 'Pending'
        );
        """
    )

    # bets
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS bets (
            bet_id     INTEGER PRIMARY KEY,
            match_id   INTEGER,
            bet_type   TEXT,
            selection  TEXT,
            stake      REAL,
            odds       REAL,
            outcome    TEXT DEFAULT 'Pending',
            FOREIGN KEY (match_id) REFERENCES matches(match_id)
        );
        """
    )

    # users
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            user_id   INTEGER PRIMARY KEY,
            name      TEXT NOT NULL,
            state_ref TEXT,
            phone     TEXT,
            refs      TEXT              -- JSON object of commission rates
        );
        """
    )

    conn.commit()
    conn.close()


# initialise DB
init_db()

# ============================================================
# Constants / options
# ============================================================

STATE_OPTIONS = [
    "Ref A",
    "Ref B",
    "Ref C",
    "Umpire",
    "Third Umpire",
    "Match Referee",
    "Other",
]

BET_TYPES = ["Match Winner", "Top Scorer"]


# ============================================================
# Main Application
# ============================================================


class BettingApp(tk.Tk):
    """Desktop GUI for managing cricket betting."""

    def __init__(self):
        super().__init__()
        self.title("Cricket Betting Manager")
        self.geometry("1150x780")

        # references for pop-up windows
        self.user_win: tk.Toplevel | None = None
        self.selected_user_id: int | None = None

        # build UI
        self._build_menubar()
        self._build_notebook()

        # shortcuts
        self.bind_all("<F1>", lambda _e: self.open_user_entry())
        self.bind_all("<F2>", lambda _e: self.open_team_entry())
        self.bind_all("<Control-s>", lambda _e: self.open_state_entry())

    # --------------------------------------------------------
    # Menubar
    # --------------------------------------------------------
    def _build_menubar(self) -> None:
        menubar = tk.Menu(self)

        entry_menu = tk.Menu(menubar, tearoff=0)
        entry_menu.add_command(label="User", accelerator="F1", command=self.open_user_entry)
        entry_menu.add_command(label="Team", accelerator="F2", command=self.open_team_entry)
        entry_menu.add_command(label="State/Ref", accelerator="Ctrl+S", command=self.open_state_entry)
        menubar.add_cascade(label="Entry", menu=entry_menu)

        match_menu = tk.Menu(menubar, tearoff=0)
        match_menu.add_command(label="Add Match", command=lambda: self._show_tab(self.add_match_tab_frame))
        menubar.add_cascade(label="Match", menu=match_menu)

        result_menu = tk.Menu(menubar, tearoff=0)
        result_menu.add_command(label="Enter Results", command=lambda: self._show_tab(self.results_tab_frame))
        menubar.add_cascade(label="Result", menu=result_menu)

        report_menu = tk.Menu(menubar, tearoff=0)
        report_menu.add_command(label="View Reports", command=lambda: self._show_tab(self.reports_tab_frame))
        menubar.add_cascade(label="Report", menu=report_menu)

        settling_menu = tk.Menu(menubar, tearoff=0)
        settling_menu.add_command(label="Settle Bets", command=lambda: self._show_tab(self.results_tab_frame))
        menubar.add_cascade(label="Settling", menu=settling_menu)

        settings_menu = tk.Menu(menubar, tearoff=0)
        settings_menu.add_command(
            label="Preferences",
            command=lambda: messagebox.showinfo("Settings", "Preferences window (to-do)"),
        )
        menubar.add_cascade(label="Settings", menu=settings_menu)

        tools_menu = tk.Menu(menubar, tearoff=0)
        tools_menu.add_command(label="Database Backup…", command=self._backup_database)
        menubar.add_cascade(label="Tools", menu=tools_menu)

        register_menu = tk.Menu(menubar, tearoff=0)
        register_menu.add_command(label="Register User", command=self.open_user_entry)
        menubar.add_cascade(label="Register", menu=register_menu)

        menubar.add_command(label="Exit", command=self.quit)
        self.config(menu=menubar)

    # --------------------------------------------------------
    # Notebook
    # --------------------------------------------------------
    def _build_notebook(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        self.add_match_tab_frame = self._create_add_match_tab()
        self.add_bet_tab_frame = self._create_add_bet_tab()
        self.results_tab_frame = self._create_results_tab()
        self.reports_tab_frame = self._create_reports_tab()

    def _show_tab(self, frame: ttk.Frame):
        self.notebook.select(self.notebook.index(frame))

    # =========================================================
    # USER MANAGER
    # =========================================================
    def open_user_entry(self):
        if self.user_win and self.user_win.winfo_exists():
            self.user_win.lift()
            return

        self.user_win = tk.Toplevel(self)
        self.user_win.title("User Manager")
        self.user_win.geometry("1000x680")  # Increased window height

        # search bar
        search_frame = ttk.Frame(self.user_win)
        search_frame.pack(fill=tk.X, padx=10, pady=5)
        self.user_search_var = tk.StringVar()
        ttk.Entry(search_frame, textvariable=self.user_search_var, width=40).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(search_frame, text="Search", command=self._search_users).pack(side=tk.LEFT)
        ttk.Button(search_frame, text="Clear", command=self._clear_user_search).pack(side=tk.LEFT, padx=5)

        # main content
        content = ttk.Frame(self.user_win)
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self._build_user_tree(content)
        self._build_user_form(content)

        self._load_users()
        self.user_win.protocol("WM_DELETE_WINDOW", self._close_user_window)

    # ---- tree
    def _build_user_tree(self, parent):
        frame = ttk.Frame(parent)
        frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        cols = ("ID", "Name", "State/Ref", "Phone", "Refs")
        self.users_tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse")
        for col in cols:
            self.users_tree.heading(col, text=col)
            self.users_tree.column(col, width=130 if col != "Refs" else 230, anchor="center")

        y_scr = ttk.Scrollbar(frame, orient="vertical", command=self.users_tree.yview)
        x_scr = ttk.Scrollbar(frame, orient="horizontal", command=self.users_tree.xview)
        self.users_tree.configure(yscroll=y_scr.set, xscroll=x_scr.set)
        self.users_tree.grid(row=0, column=0, sticky="nsew")
        y_scr.grid(row=0, column=1, sticky="ns")
        x_scr.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.users_tree.bind("<<TreeviewSelect>>", self._on_user_tree_select)

    # ---- form
    def _build_user_form(self, parent):
        form = ttk.Frame(parent)
        form.pack(side=tk.LEFT, fill=tk.Y, padx=(10, 0))

        # Basic Info
        ttk.Label(form, text="Name:").grid(row=0, column=0, sticky="e", pady=2)
        self.user_name_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.user_name_var, width=28).grid(row=0, column=1, columnspan=4, sticky="w")

        ttk.Label(form, text="State/Ref:").grid(row=1, column=0, sticky="e", pady=2)
        self.user_state_var = tk.StringVar()
        self.state_combo = ttk.Combobox(form, textvariable=self.user_state_var, values=STATE_OPTIONS,
                                        state="readonly", width=20)
        self.state_combo.grid(row=1, column=1, sticky="w")
        self.state_extra_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.state_extra_var, width=10).grid(row=1, column=2, padx=(5, 0), sticky="w")

        ttk.Label(form, text="Telephone:").grid(row=2, column=0, sticky="e", pady=2)
        self.user_phone_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.user_phone_var, width=28).grid(row=2, column=1, columnspan=4, sticky="w")

        # Commission Options
        self.PERCENT_OPTIONS = [f"{i}%" for i in range(1, 11)] + ["Other"]
        commission_fields = [
            ("Match Commission:", "match_comm1_type", "match_comm1_val",
             "match_comm2_type", "match_comm2_val"),
            ("Session Commission:", "session_comm1_type", "session_comm1_val",
             "session_comm2_type", "session_comm2_val"),
            ("Match Patti:", "match_patti1_type", "match_patti1_val",
             "match_patti2_type", "match_patti2_val"),
            ("Session Patti:", "session_patti1_type", "session_patti1_val",
             "session_patti2_type", "session_patti2_val"),
        ]

        # Create commission fields
        for row_idx, (label, type1, val1, type2, val2) in enumerate(commission_fields, start=3):
            ttk.Label(form, text=label).grid(row=row_idx, column=0, sticky="e", pady=2)

            # First pair
            setattr(self, type1, tk.StringVar())
            setattr(self, val1, tk.StringVar())
            cb1 = ttk.Combobox(form, textvariable=getattr(self, type1),
                               values=self.PERCENT_OPTIONS, state="readonly", width=8)
            cb1.grid(row=row_idx, column=1, sticky="w")
            cb1.bind("<<ComboboxSelected>>", self._handle_percent_select)
            ttk.Entry(form, textvariable=getattr(self, val1), width=8, state="disabled"
                      ).grid(row=row_idx, column=2, padx=(5, 0), sticky="w")

            # Second pair
            setattr(self, type2, tk.StringVar())
            setattr(self, val2, tk.StringVar())
            cb2 = ttk.Combobox(form, textvariable=getattr(self, type2),
                               values=self.PERCENT_OPTIONS, state="readonly", width=8)
            cb2.grid(row=row_idx, column=3, padx=(10, 0), sticky="w")
            cb2.bind("<<ComboboxSelected>>", self._handle_percent_select)
            ttk.Entry(form, textvariable=getattr(self, val2), width=8, state="disabled"
                      ).grid(row=row_idx, column=4, padx=(5, 0), sticky="w")

        # Cutting Reference
        ttk.Label(form, text="Cutting Reference:").grid(row=7, column=0, sticky="e", pady=2)
        self.cutting_ref_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.cutting_ref_var, width=20).grid(
            row=7, column=1, columnspan=4, sticky="w")

        # Buttons
        btns = ttk.Frame(form)
        btns.grid(row=8, column=0, columnspan=5, pady=10)
        ttk.Button(btns, text="Save / Update", command=self._save_user).pack(side=tk.LEFT, padx=5)
        ttk.Button(btns, text="Clear", command=self._clear_user_form).pack(side=tk.LEFT, padx=5)

    def _handle_percent_select(self, event):
        widget = event.widget
        type_var = widget.cget("textvariable")
        entry_var_name = type_var.replace("_type", "_val")
        entry_var = getattr(self, entry_var_name)

        selected = widget.get()
        if selected == "Other":
            entry_var.set("")
            widget.master.children[entry_var_name].config(state="normal")
        else:
            entry_var.set(selected.strip("%"))
            widget.master.children[entry_var_name].config(state="disabled")

    def _close_user_window(self):
        self.user_win.destroy()
        self.user_win = None
        self.selected_user_id = None

    def _search_users(self):
        self._load_users(self.user_search_var.get().strip())

    def _clear_user_search(self):
        self.user_search_var.set("")
        self._load_users()

    def _on_user_tree_select(self, _):
        sel = self.users_tree.selection()
        if not sel:
            return
        vals = self.users_tree.item(sel[0], "values")
        self.selected_user_id = int(vals[0])

        # Basic Info
        self.user_name_var.set(vals[1])
        state_full = vals[2] or ""
        base_state, extra_state = (state_full.split("|", 1) + [""])[:2]
        self.user_state_var.set(base_state)
        self.state_extra_var.set(extra_state)
        self.user_phone_var.set(vals[3])

        # Commission Rates
        refs = json.loads(vals[4]) if vals[4] else {}

        def set_commission(type_var, val_var, value):
            if value.endswith("%") and value[:-1].isdigit():
                percent = value[:-1]
                if f"{percent}%" in self.PERCENT_OPTIONS:
                    getattr(self, type_var).set(f"{percent}%")
                    getattr(self, val_var).set(percent)
                    return
            getattr(self, type_var).set("Other")
            getattr(self, val_var).set(value.strip("%"))

        commissions = [
            ("match_comm1_type", "match_comm1_val", refs.get("match_comm", ["0%"])[0]),
            ("match_comm2_type", "match_comm2_val", refs.get("match_comm", ["0%"])[1]),
            ("session_comm1_type", "session_comm1_val", refs.get("session_comm", ["0%"])[0]),
            ("session_comm2_type", "session_comm2_val", refs.get("session_comm", ["0%"])[1]),
            ("match_patti1_type", "match_patti1_val", refs.get("match_patti", ["0%"])[0]),
            ("match_patti2_type", "match_patti2_val", refs.get("match_patti", ["0%"])[1]),
            ("session_patti1_type", "session_patti1_val", refs.get("session_patti", ["0%"])[0]),
            ("session_patti2_type", "session_patti2_val", refs.get("session_patti", ["0%"])[1]),
        ]

        for type_var, val_var, value in commissions:
            set_commission(type_var, val_var, value)
    def _clear_user_form(self):
        self.selected_user_id = None
        # Basic Info
        self.user_name_var.set("")
        self.user_state_var.set("")
        self.state_extra_var.set("")
        self.user_phone_var.set("")

        # Commission Rates
        self.match_comm1_var.set("")
        self.match_comm2_var.set("")
        self.session_comm1_var.set("")
        self.session_comm2_var.set("")
        self.match_patti1_var.set("")
        self.match_patti2_var.set("")
        self.session_patti1_var.set("")
        self.session_patti2_var.set("")
        self.cutting_ref_var.set("")

        self.users_tree.selection_remove(self.users_tree.selection())

    def _save_user(self):
        name = self.user_name_var.get().strip()
        if not name:
            messagebox.showwarning("Input", "Name is required.")
            return

        # Validate commission pairs
        commission_errors = []
        pairs = [
            ("Match Commission", self.match_comm1_var, self.match_comm2_var),
            ("Session Commission", self.session_comm1_var, self.session_comm2_var),
            ("Match Patti", self.match_patti1_var, self.match_patti2_var),
            ("Session Patti", self.session_patti1_var, self.session_patti2_var),
        ]

        for label, var1, var2 in pairs:
            val1 = var1.get().strip()
            val2 = var2.get().strip()
            if val1 != val2:
                commission_errors.append(f"{label} values must match")

        if commission_errors:
            messagebox.showwarning("Input", "\n".join(commission_errors))
            return

        # Build refs structure
        refs = {
            "match_comm": [
                self._get_commission_value("match_comm1_type", "match_comm1_val"),
                self._get_commission_value("match_comm2_type", "match_comm2_val")
            ],
            "session_comm": [
                self._get_commission_value("session_comm1_type", "session_comm1_val"),
                self._get_commission_value("session_comm2_type", "session_comm2_val")
            ],
            "match_patti": [
                self._get_commission_value("match_patti1_type", "match_patti1_val"),
                self._get_commission_value("match_patti2_type", "match_patti2_val")
            ],
            "session_patti": [
                self._get_commission_value("session_patti1_type", "session_patti1_val"),
                self._get_commission_value("session_patti2_type", "session_patti2_val")
            ],
            "cutting_ref": self.cutting_ref_var.get()
        }

        state_ref = self.user_state_var.get().strip()
        extra = self.state_extra_var.get().strip()
        state_full = f"{state_ref}|{extra}" if extra else state_ref
        phone = self.user_phone_var.get().strip()
        refs_json = json.dumps(refs)

        conn = create_connection()
        cur = conn.cursor()
        try:
            if self.selected_user_id:
                cur.execute(
                    "UPDATE users SET name=?, state_ref=?, phone=?, refs=? WHERE user_id=?",
                    (name, state_full, phone, refs_json, self.selected_user_id),
                )
            else:
                cur.execute(
                    "INSERT INTO users (name, state_ref, phone, refs) VALUES (?, ?, ?, ?)",
                    (name, state_full, phone, refs_json),
                )
            conn.commit()
            self._load_users()
            self._clear_user_form()
            messagebox.showinfo("Success", "User saved.")
        except Exception as exc:
            messagebox.showerror("Error", f"Could not save user: {exc}")
        finally:
            conn.close()

    def _get_commission_value(self, type_var, val_var):
        type_val = getattr(self, type_var).get()
        val = getattr(self, val_var).get()

        if type_val == "Other":
            if not val.isdigit():
                raise ValueError("Custom value must be a number")
            return f"{val}%"
        return type_val

    def _load_users(self, filter_text: str | None = None):
        conn = create_connection()
        cur = conn.cursor()
        if filter_text:
            cur.execute(
                "SELECT user_id, name, state_ref, phone, refs FROM users WHERE name LIKE ? ORDER BY user_id DESC",
                (f"%{filter_text}%",),
            )
        else:
            cur.execute("SELECT user_id, name, state_ref, phone, refs FROM users ORDER BY user_id DESC")
        rows = cur.fetchall()
        conn.close()

        self.users_tree.delete(*self.users_tree.get_children())
        for row in rows:
            self.users_tree.insert("", tk.END, values=row)

    # =========================================================
    # Placeholder Entry options
    # =========================================================
    def open_team_entry(self):
        messagebox.showinfo("Entry", "Team entry (future feature)")

    def open_state_entry(self):
        messagebox.showinfo("Entry", "State/Ref entry (future feature)")

    # =========================================================
    # Add Match Tab
    # =========================================================
    def _create_add_match_tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Add Match")

        labels = ["Team A:", "Team B:", "Date (YYYY-MM-DD):", "Venue:"]
        for r, text in enumerate(labels):
            ttk.Label(tab, text=text).grid(row=r, column=0, pady=5, sticky="e")

        self.team_a_entry = ttk.Entry(tab, width=30)
        self.team_b_entry = ttk.Entry(tab, width=30)
        self.date_entry = ttk.Entry(tab, width=30)
        self.venue_entry = ttk.Entry(tab, width=30)
        self.team_a_entry.grid(row=0, column=1, pady=5, sticky="w")
        self.team_b_entry.grid(row=1, column=1, pady=5, sticky="w")
        self.date_entry.grid(row=2, column=1, pady=5, sticky="w")
        self.venue_entry.grid(row=3, column=1, pady=5, sticky="w")

        ttk.Button(tab, text="Save Match", command=self.save_match).grid(row=4, column=0, columnspan=2, pady=10)
        return tab

    def save_match(self):
        team_a, team_b = self.team_a_entry.get().strip(), self.team_b_entry.get().strip()
        if not team_a or not team_b:
            messagebox.showwarning("Input", "Both teams are required.")
            return

        conn = create_connection()
        cur = conn.cursor()
        try:
            cur.execute(
                "INSERT INTO matches (team_a, team_b, date, venue) VALUES (?, ?, ?, ?)",
                (team_a, team_b, self.date_entry.get().strip(), self.venue_entry.get().strip()),
            )
            conn.commit()
            messagebox.showinfo("Success", "Match added.")
        except Exception as exc:
            messagebox.showerror("Error", f"Could not add match: {exc}")
        finally:
            conn.close()
            self.match_combobox["values"] = self._get_matches()
            self.results_match_combobox["values"] = self._get_matches()
            for widget in (self.team_a_entry, self.team_b_entry, self.date_entry, self.venue_entry):
                widget.delete(0, tk.END)

    # =========================================================
    # Place Bet Tab
    # =========================================================
    def _create_add_bet_tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Place Bet")

        labels = ["Match:", "Bet Type:", "Selection:", "Stake ($):", "Odds:"]
        for r, text in enumerate(labels):
            ttk.Label(tab, text=text).grid(row=r, column=0, pady=5, sticky="e")

        self.match_combobox = ttk.Combobox(tab, width=45, state="readonly", values=self._get_matches())
        self.bet_type_combobox = ttk.Combobox(tab, width=42, state="readonly", values=BET_TYPES)
        self.selection_entry = ttk.Entry(tab, width=45)
        self.stake_entry = ttk.Entry(tab, width=15)
        self.odds_entry = ttk.Entry(tab, width=15)

        self.match_combobox.grid(row=0, column=1, pady=5, sticky="w")
        self.bet_type_combobox.grid(row=1, column=1, pady=5, sticky="w")
        self.selection_entry.grid(row=2, column=1, pady=5, sticky="w")
        self.stake_entry.grid(row=3, column=1, pady=5, sticky="w")
        self.odds_entry.grid(row=4, column=1, pady=5, sticky="w")

        ttk.Button(tab, text="Place Bet", command=self.save_bet).grid(row=5, column=0, columnspan=2, pady=10)
        return tab

    def _get_matches(self) -> list[str]:
        conn = create_connection()
        cur = conn.cursor()
        cur.execute("SELECT match_id, team_a || ' vs ' || team_b FROM matches ORDER BY match_id DESC")
        rows = cur.fetchall()
        conn.close()
        return [f"{mid} - {name}" for mid, name in rows]

    def save_bet(self):
        match_str = self.match_combobox.get()
        if not match_str:
            messagebox.showwarning("Input", "Please select a match.")
            return

        try:
            match_id = int(match_str.split(" - ")[0])
        except ValueError:
            messagebox.showerror("Input", "Invalid match selection.")
            return

        try:
            stake = float(self.stake_entry.get())
            odds = float(self.odds_entry.get())
        except ValueError:
            messagebox.showerror("Input", "Stake and Odds must be numeric.")
            return

        if stake <= 0 or odds <= 0:
            messagebox.showwarning("Input", "Stake and Odds must be positive numbers.")
            return

        conn = create_connection()
        cur = conn.cursor()
        try:
            cur.execute(
                "INSERT INTO bets (match_id, bet_type, selection, stake, odds) VALUES (?, ?, ?, ?, ?)",
                (
                    match_id,
                    self.bet_type_combobox.get().strip(),
                    self.selection_entry.get().strip(),
                    stake,
                    odds,
                ),
            )
            conn.commit()
            messagebox.showinfo("Success", "Bet placed.")
        except Exception as exc:
            messagebox.showerror("Error", f"Could not place bet: {exc}")
        finally:
            conn.close()
            self._load_bets()
            for widget in (self.selection_entry, self.stake_entry, self.odds_entry):
                widget.delete(0, tk.END)

    # =========================================================
    # Results / Settlement Tab
    # =========================================================
    def _create_results_tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Results")

        labels = ["Match:", "Actual Top Scorer:", "Winning Team:"]
        for r, text in enumerate(labels):
            ttk.Label(tab, text=text).grid(row=r, column=0, pady=5, sticky="e")

        self.results_match_combobox = ttk.Combobox(tab, width=45, state="readonly", values=self._get_matches())
        self.top_scorer_entry = ttk.Entry(tab, width=45)
        self.winner_entry = ttk.Entry(tab, width=45)

        self.results_match_combobox.grid(row=0, column=1, pady=5, sticky="w")
        self.top_scorer_entry.grid(row=1, column=1, pady=5, sticky="w")
        self.winner_entry.grid(row=2, column=1, pady=5, sticky="w")

        ttk.Button(tab, text="Settle Bets", command=self.settle_bets).grid(row=3, column=0, columnspan=2, pady=10)
        return tab

    def settle_bets(self):
        match_str = self.results_match_combobox.get()
        if not match_str:
            messagebox.showwarning("Input", "Select a match to settle.")
            return

        match_id = int(match_str.split(" - ")[0])
        winner = self.winner_entry.get().strip()
        if not winner:
            messagebox.showwarning("Input", "Winning team is required.")
            return

        conn = create_connection()
        cur = conn.cursor()
        try:
            cur.execute("UPDATE matches SET result=? WHERE match_id=?", (f"{winner} won", match_id))

            # settle bets
            cur.executescript(
                f"""
                UPDATE bets
                   SET outcome = CASE WHEN selection = '{self.top_scorer_entry.get().strip()}' THEN 'won' ELSE 'lost' END
                 WHERE match_id = {match_id} AND bet_type = 'Top Scorer';

                UPDATE bets
                   SET outcome = CASE WHEN selection = '{winner}' THEN 'won' ELSE 'lost' END
                 WHERE match_id = {match_id} AND bet_type = 'Match Winner';
                """
            )
            conn.commit()
            messagebox.showinfo("Success", "Bets settled.")
        except Exception as exc:
            messagebox.showerror("Error", f"Could not settle bets: {exc}")
        finally:
            conn.close()
            self._load_bets()
            self._update_profit_label()
            self.top_scorer_entry.delete(0, tk.END)
            self.winner_entry.delete(0, tk.END)

    # =========================================================
    # Reports Tab
    # =========================================================
    def _create_reports_tab(self) -> ttk.Frame:
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Reports")

        ttk.Button(tab, text="Update Profit/Loss", command=self._update_profit_label).pack(pady=10)
        self.profit_label = ttk.Label(tab, text="Total Profit/Loss: $0.00", font=("Segoe UI", 12, "bold"))
        self.profit_label.pack()

        cols = ("ID", "Match", "Type", "Selection", "Outcome")
        self.bets_tree = ttk.Treeview(tab, columns=cols, show="headings", height=15)
        for col in cols:
            self.bets_tree.heading(col, text=col)
            self.bets_tree.column(col, anchor="center")
        self.bets_tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self._load_bets()
        return tab

    def _update_profit_label(self):
        conn = create_connection()
        cur = conn.cursor()
        cur.execute(
            """
            SELECT COALESCE(SUM(CASE
                WHEN outcome = 'won' THEN stake * odds - stake
                WHEN outcome = 'lost' THEN -stake
                ELSE 0 END), 0)
            FROM bets
            """
        )
        total = cur.fetchone()[0]
        conn.close()
        self.profit_label.config(text=f"Total Profit/Loss: ${total:,.2f}")

    def _load_bets(self):
        conn = create_connection()
        cur = conn.cursor()
        cur.execute(
            """
            SELECT b.bet_id,
                   m.team_a || ' vs ' || m.team_b,
                   b.bet_type,
                   b.selection,
                   b.outcome
              FROM bets b
              JOIN matches m ON b.match_id = m.match_id
              ORDER BY b.bet_id DESC
            """
        )
        rows = cur.fetchall()
        conn.close()

        self.bets_tree.delete(*self.bets_tree.get_children())
        for row in rows:
            self.bets_tree.insert("", tk.END, values=row)

    # =========================================================
    # Tools
    # =========================================================
    def _backup_database(self):
        if not os.path.exists(DB_FILE):
            messagebox.showerror("Backup", "Database file not found.")
            return
        backup_name = f"betting_backup_{datetime.now():%Y%m%d_%H%M%S}.db"
        try:
            shutil.copy(DB_FILE, backup_name)
            messagebox.showinfo("Backup", f"Database copied to {backup_name}")
        except Exception as exc:
            messagebox.showerror("Backup", f"Backup failed: {exc}")


# ============================================================
# Run application
# ============================================================
if __name__ == "__main__":
    app = BettingApp()
    app.mainloop()
