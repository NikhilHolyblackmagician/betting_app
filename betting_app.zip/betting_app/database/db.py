import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / "betting.db"


def create_connection():
    """Create a database connection."""
    return sqlite3.connect(DB_PATH)


def init_db():
    """Initialize database tables."""
    conn = create_connection()
    cursor = conn.cursor()

    # Existing tables
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS teams (
            team_id INTEGER PRIMARY KEY,
            team_name TEXT NOT NULL UNIQUE,
            event_name TEXT,
            event_date TEXT,
            captain TEXT,
            home_ground TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id INTEGER PRIMARY KEY,
            match_id INTEGER NOT NULL,
            type TEXT CHECK(type IN ('K', 'L')) NOT NULL,
            amount REAL NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            description TEXT,
            FOREIGN KEY (match_id) REFERENCES matches(match_id)
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reports (
            report_id INTEGER PRIMARY KEY,
            match_id INTEGER,
            report_name TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'Undeclared',
            content TEXT,
            FOREIGN KEY (match_id) REFERENCES matches(match_id)
        )
    """)
    # Add other tables (users, matches, bets) here...

    conn.commit()
    conn.close()


# Initialize when module loads
init_db()